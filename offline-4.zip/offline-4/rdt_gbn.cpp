#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <queue>
using namespace std;

/* ******************************************************************
 ALTERNATING BIT AND GO-BACK-N NETWORK EMULATOR: SLIGHTLY MODIFIED
 FROM VERSION 1.1 of J.F.Kurose

   This code should be used for PA2, unidirectional or bidirectional
   data transfer protocols (from A to B. Bidirectional transfer of data
   is for extra credit and is not required).  Network properties:
   - one way network delay averages five time units (longer if there
       are other messages in the channel for GBN), but can be larger
   - packets can be corrupted (either the header or the data portion)
       or lost, according to user-defined probabilities
   - packets will be delivered in the order in which they were sent
       (although some can be lost).
**********************************************************************/
#define A 0
#define B 1
#define TimeOut 15
#define MaxSequenceNumber 7
#define max_buf_size 8
#define WindowSize 4
#define BIDIRECTIONAL 0 /* change to 1 if you're doing extra credit */
/* and write a routine called B_output */

/* a "msg" is the data unit passed from layer 5 (teachers code) to layer  */
/* 4 (students' code).  It contains the data (characters) to be delivered */
/* to layer 5 via the students transport level protocol entities.         */
struct msg
{
    char data[20];
};

FILE *outDoc;
/* a packet is the data unit passed from layer 4 (students code) to layer */
/* 3 (teachers code).  Note the pre-defined packet structure, which all   */
/* students must follow. */
struct pkt
{
    int seqnum;
    int acknum;
    int checksum;
    char payload[20];
};

/********* FUNCTION PROTOTYPES. DEFINED IN THE LATER PART******************/
void starttimer(int AorB, float increment);
void stoptimer(int AorB);
void tolayer3(int AorB, struct pkt packet);
void tolayer5(int AorB, char datasent[20]);


int base;
int next_sequence_number_at_A;
int expected_acknum_at_A;
int expected_sequence_number_at_B;
int previous_correct_seqNum_at_B;
int items_in_message_buffer;
int packets_sent_count;
int timer_on_flag;

queue <int> Expiry_Time_Queue; 
queue <int> matching_sequence_number_queue;
queue <struct msg> message_buffer;
queue <struct pkt> packets_under_consideration;


float time = 0.000;

int calculate_checksum(struct pkt packet)
{
	int total=0;
	int i;
	for(i=0;i<strlen(packet.payload);i++)
	{
		total+=packet.payload[i];
	}
	total+=packet.seqnum;
	total+=packet.acknum;
	return total;
}
struct pkt make_packet(int seq, int ack, char data[20])
{
	struct pkt pack;
	pack.payload[0] = '\0';
	pack.seqnum=seq;
	pack.acknum=ack;
	int total=0;
	int i;
	for(i=0;i<strlen(data);i++)
	{
		total+=data[i];
	}
	total+=seq;
	total+=ack;
	pack.checksum=total;
	fprintf(outDoc,"Making packet: seq=%d, ack=%d, data= %s, checksum=%d\n",pack.seqnum, pack.acknum, data, total);
	strcpy(pack.payload,data);
	return pack;

}




/********* STUDENTS WRITE THE NEXT SEVEN ROUTINES *********/

/* called from layer 5, passed the data to be sent to other side */
void A_output(struct msg message)
{
	if(packets_sent_count<WindowSize)//if(next_sequence_number_at_A < (base+WindowSize)%8)
	{
		struct pkt pack=make_packet(next_sequence_number_at_A, next_sequence_number_at_A , message.data);
		packets_under_consideration.push(pack);
		packets_sent_count++; 
		Expiry_Time_Queue.push(time+TimeOut);
		matching_sequence_number_queue.push(next_sequence_number_at_A);
		next_sequence_number_at_A=(next_sequence_number_at_A+1)%8;
		fprintf(outDoc,"At A: Sending packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", pack.payload, pack.seqnum, pack.acknum, pack.checksum);
		tolayer3(A,pack);
		if(timer_on_flag==0 )
		{
			int exp_time=Expiry_Time_Queue.front();
			//Expiry_Time_Queue.pop();
			starttimer(A,exp_time-time);
			timer_on_flag=1;
		}

		

	}
	else
	{
		if(items_in_message_buffer < max_buf_size)
		{
			//strcpy(message_buffer[items_in_message_buffer],message.data);
			message_buffer.push(message);
			items_in_message_buffer++;
		}
		else
		{
			fprintf(outDoc,"Message Buffer Full, message ignored!!!\n");
		}
	}

}

/* need be completed only for extra credit */
void B_output(struct msg message)
{

}

/* called from layer 3, when a packet arrives for layer 4 */
void A_input(struct pkt packet)
{
	int ret_cs=calculate_checksum(packet);
	int correct_ack_received=0;
	if(ret_cs==packet.checksum)
	{
		int number_of_pops=0;
		if(base>=5)
		{
			int difference=MaxSequenceNumber-base;
			if(packet.acknum>=base && packet.acknum<=base+difference)////
			{
				 number_of_pops=packet.acknum-base+1;
				// base=(packet.acknum+1)%8;
				correct_ack_received=1;

			}
			else if(packet.acknum>=0 && packet.acknum<(WindowSize-difference-1))
			{
				 number_of_pops=packet.acknum+difference+2;
				// base=(packet.acknum+1)%8;
				correct_ack_received=1;

			}
		}
		else
		{
			if(packet.acknum>=base && packet.acknum<base+WindowSize)
			{
				 number_of_pops=packet.acknum-base+1;
				// base=(packet.acknum+1)%8;
				correct_ack_received=1;

			}
		}
		if(correct_ack_received){
			int count=number_of_pops;
			fprintf(outDoc,"At A: Correctly received packets:\n");

			while(count>0)
			{
	 			int size=packets_under_consideration.size();

				if(size==1)
				{
					struct pkt p=packets_under_consideration.front();
					fprintf(outDoc,"1: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", p.payload, p.seqnum, p.acknum, p.checksum);
					packets_under_consideration.pop();
					Expiry_Time_Queue.pop();
					matching_sequence_number_queue.pop();
					fprintf(outDoc,"timer_on_flag= %d\n", timer_on_flag);
					if(timer_on_flag)
					{
						fprintf(outDoc,"Here\n");
						stoptimer(A);
						timer_on_flag=0;
					}


				}
				else if(size>1)
				{
					struct pkt p=packets_under_consideration.front();
					fprintf(outDoc,"2: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", p.payload, p.seqnum, p.acknum, p.checksum);
					packets_under_consideration.pop();
					Expiry_Time_Queue.pop();
					matching_sequence_number_queue.pop();
					if(timer_on_flag)
					{
						stoptimer(A);
						timer_on_flag=0;
					}
					int t1=Expiry_Time_Queue.front();
					if(!timer_on_flag)
					{
						starttimer(A,t1-time);
						timer_on_flag=1;
					}


				}


				count--;
			}

			base=(packet.acknum+1)%8;
			packets_sent_count=packets_under_consideration.size();

			while(packets_sent_count<=WindowSize)
			{
				if(items_in_message_buffer>0)
				{
					fprintf(outDoc,"OUt of loop,packets_sent_count = %d \n",packets_sent_count);
					char buf[20];
					strcpy(buf,message_buffer.front().data);
					message_buffer.pop();
					items_in_message_buffer--;
					struct pkt pack=make_packet(next_sequence_number_at_A, next_sequence_number_at_A , buf);
					packets_under_consideration.push(pack);
					packets_sent_count++; 
					Expiry_Time_Queue.push(time+TimeOut);
					matching_sequence_number_queue.push(next_sequence_number_at_A);
					next_sequence_number_at_A=(next_sequence_number_at_A+1)%8;
					fprintf(outDoc,"At A: Sending packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", pack.payload, pack.seqnum, pack.acknum, pack.checksum);
					tolayer3(A,pack);
					if(timer_on_flag==0 && packets_sent_count==0)
					{
						starttimer(A,TimeOut);
						timer_on_flag=1;
					}
				}
				else
				{
					break;
				}
			}



		}



	}
	else
	{
		fprintf(outDoc,"At A: Checksum Error for ACK packet\n");
		
	}
/*dup ack retransmit written here*/
	if(!correct_ack_received)
	{
			fprintf(outDoc,"Packet acknowledgement number: %d not within current window. So duplicated acknowledgement received.\n", packet.acknum);
			if(timer_on_flag)
			{
				stoptimer(A);
				timer_on_flag=0;
			}
			queue<struct pkt> copy_queue=packets_under_consideration;
			int size=copy_queue.size();
			for(int i=0;i< size;i++)
			{
				Expiry_Time_Queue.pop();
				matching_sequence_number_queue.pop();
			}
			for(int i=0;i<size;i++)
			{
				struct pkt pack=copy_queue.front();
				copy_queue.pop();
				Expiry_Time_Queue.push(time+TimeOut);
				matching_sequence_number_queue.push(pack.seqnum);
				fprintf(outDoc,"At A: Retransmitting packet on dup ack: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", pack.payload, pack.seqnum, pack.acknum, pack.checksum);
				tolayer3(A,pack);
				if(timer_on_flag==0 )
				{
					int exp_time=Expiry_Time_Queue.front();
					//Expiry_Time_Queue.pop();
					starttimer(A,exp_time-time);
					timer_on_flag=1;
				}


			}



	}


}




/* called when A's timer goes off */
void A_timerinterrupt(void)
{
	timer_on_flag=0;
	queue<struct pkt> copy_queue=packets_under_consideration;
	int size=copy_queue.size();
	for(int i=0;i< size;i++)
	{
		Expiry_Time_Queue.pop();
		matching_sequence_number_queue.pop();
	}
	for(int i=0;i<size;i++)
	{
		struct pkt pack=copy_queue.front();
		copy_queue.pop();
		Expiry_Time_Queue.push(time+TimeOut);
		matching_sequence_number_queue.push(pack.seqnum);
		fprintf(outDoc,"At A: Retransmitting packet on timeout: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", pack.payload, pack.seqnum, pack.acknum, pack.checksum);
		tolayer3(A,pack);
		if(timer_on_flag==0 )
		{
			int exp_time=Expiry_Time_Queue.front();
			//Expiry_Time_Queue.pop();
			starttimer(A,exp_time-time);
			timer_on_flag=1;
		}


	}



}

/* the following routine will be called once (only) before any other */
/* entity A routines are called. You can use it to do any initialization */
void A_init(void)
{
	 base=0;
	 next_sequence_number_at_A=0;
	 expected_acknum_at_A=0;
	 items_in_message_buffer=0;
	 packets_sent_count=0;
	 timer_on_flag=0;

}

/* Note that with simplex transfer from a-to-B, there is no B_output() */

/* called from layer 3, when a packet arrives for layer 4 at B*/
void B_input(struct pkt packet)
{
	int ret_cs=calculate_checksum(packet);
	if(ret_cs==packet.checksum && packet.seqnum==expected_sequence_number_at_B)
	{
		tolayer5(B,packet.payload);
		//fprintf(outDoc,"At B: Packet (%s) correctly received!!! \n",packet.payload);
		fprintf(outDoc,"At B: Received packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", packet.payload, packet.seqnum, packet.acknum, packet.checksum);
		struct pkt ack_pack=make_packet(packet.seqnum,expected_sequence_number_at_B,"ACK");
		previous_correct_seqNum_at_B=expected_sequence_number_at_B;
		expected_sequence_number_at_B=(expected_sequence_number_at_B+1)%8;
		fprintf(outDoc,"At B: Sending packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", ack_pack.payload, ack_pack.seqnum, ack_pack.acknum, ack_pack.checksum);
		tolayer3(B, ack_pack);
		return;

	}
	else if(ret_cs!=packet.checksum)
	{
		fprintf(outDoc,"At B: Corrupted packet (%s) received!\n",packet.payload);
		struct pkt nack_pack=make_packet(packet.seqnum,previous_correct_seqNum_at_B,"ACK");
		fprintf(outDoc,"At B: Sending packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", nack_pack.payload, nack_pack.seqnum, nack_pack.acknum, nack_pack.checksum);
		tolayer3(B,nack_pack);
		return;

	}
	else if(packet.seqnum!=expected_sequence_number_at_B)
	{	
	fprintf(outDoc,"At B: Received sequence number(%d) did not match expected one(%d).\n", packet.seqnum, expected_sequence_number_at_B);	
		struct pkt nack_pack=make_packet(packet.seqnum,previous_correct_seqNum_at_B,"ACK");	
		fprintf(outDoc,"At B: Sending packet: data= %s, seqnum=%d, acknum=%d, checksum= %d\n", nack_pack.payload, nack_pack.seqnum, nack_pack.acknum, nack_pack.checksum);
		tolayer3(B,nack_pack);
		return;
	}

}

/* called when B's timer goes off */
void B_timerinterrupt(void)
{
    fprintf(outDoc,"  B_timerinterrupt: B doesn't have a timer. ignore.\n");
}

/* the following rouytine will be called once (only) before any other */
/* entity B routines are called. You can use it to do any initialization */
void B_init(void)
{	 
	expected_sequence_number_at_B=0;
	previous_correct_seqNum_at_B=-1;

}

/*****************************************************************
***************** NETWORK EMULATION CODE STARTS BELOW ***********
The code below emulates the layer 3 and below network environment:
    - emulates the tranmission and delivery (possibly with bit-level corruption
        and packet loss) of packets across the layer 3/4 interface
    - handles the starting/stopping of a timer, and generates timer
        interrupts (resulting in calling students timer handler).
    - generates message to be sent (passed from later 5 to 4)

THERE IS NOT REASON THAT ANY STUDENT SHOULD HAVE TO READ OR UNDERSTAND
THE CODE BELOW.  YOU SHOLD NOT TOUCH, OR REFERENCE (in your code) ANY
OF THE DATA STRUCTURES BELOW.  If you're interested in how I designed
the emulator, you're welcome to look at the code - but again, you should have
to, and you defeinitely should not have to modify
******************************************************************/

struct event
{
    float evtime;       /* event time */
    int evtype;         /* event type code */
    int eventity;       /* entity where event occurs */
    struct pkt *pktptr; /* ptr to packet (if any) assoc w/ this event */
    struct event *prev;
    struct event *next;
};
struct event *evlist = NULL; /* the event list */

/* possible events: */
#define TIMER_INTERRUPT 0
#define FROM_LAYER5 1
#define FROM_LAYER3 2

#define OFF 0
#define ON 1


int TRACE = 1;     /* for my debugging */
int nsim = 0;      /* number of messages from 5 to 4 so far */
int nsimmax = 0;   /* number of msgs to generate, then stop */

float lossprob;    /* probability that a packet is dropped  */
float corruptprob; /* probability that one bit is packet is flipped */
float lambda;      /* arrival rate of messages from layer 5 */
int ntolayer3;     /* number sent into layer 3 */
int nlost;         /* number lost in media */
int ncorrupt;      /* number corrupted by media*/

void init();
void generate_next_arrival(void);
void insertevent(struct event *p);

int main()
{
    struct event *eventptr;
    struct msg msg2give;
    struct pkt pkt2give;

    int i, j;
    char c;

    init();
    A_init();
    B_init();
    outDoc = fopen("output_gbn.doc","w");
    while (1)
    {
        eventptr = evlist; /* get next event to simulate */
        if (eventptr == NULL)
            goto terminate;
        evlist = evlist->next; /* remove this event from event list */
        if (evlist != NULL)
            evlist->prev = NULL;
        if (TRACE >= 2)
        {
            fprintf(outDoc,"\nEVENT time: %f,", eventptr->evtime);
            fprintf(outDoc,"  type: %d", eventptr->evtype);
            if (eventptr->evtype == 0)
                fprintf(outDoc,", timerinterrupt  ");
            else if (eventptr->evtype == 1)
                fprintf(outDoc,", fromlayer5 ");
            else
                fprintf(outDoc,", fromlayer3 ");
            fprintf(outDoc," entity: %d\n", eventptr->eventity);
        }
        time = eventptr->evtime; /* update time to next event time */
        if (eventptr->evtype == FROM_LAYER5)
        {
            if (nsim < nsimmax)
            {
                if (nsim + 1 < nsimmax)
                    generate_next_arrival(); /* set up future arrival */
                /* fill in msg to give with string of same letter */
                j = nsim % 26;
                for (i = 0; i < 20; i++)
                    msg2give.data[i] = 97 + j;
                msg2give.data[19] = 0;
                if (TRACE > 2)
                {
                    fprintf(outDoc,"          MAINLOOP: data given to student: ");
                    for (i = 0; i < 20; i++)
                        fprintf(outDoc,"%c", msg2give.data[i]);
                    fprintf(outDoc,"\n");
                }
                nsim++;
                if (eventptr->eventity == A)
                    A_output(msg2give);
                else
                    B_output(msg2give);
            }
        }
        else if (eventptr->evtype == FROM_LAYER3)
        {
            pkt2give.seqnum = eventptr->pktptr->seqnum;
            pkt2give.acknum = eventptr->pktptr->acknum;
            pkt2give.checksum = eventptr->pktptr->checksum;
            for (i = 0; i < 20; i++)
                pkt2give.payload[i] = eventptr->pktptr->payload[i];
            if (eventptr->eventity == A) /* deliver packet by calling */
                A_input(pkt2give); /* appropriate entity */
            else
                B_input(pkt2give);
            free(eventptr->pktptr); /* free the memory for packet */
        }
        else if (eventptr->evtype == TIMER_INTERRUPT)
        {
            if (eventptr->eventity == A)
                A_timerinterrupt();
            else
                B_timerinterrupt();
        }
        else
        {
            fprintf(outDoc,"INTERNAL PANIC: unknown event type \n");
        }
        free(eventptr);
    }

terminate:
    fprintf(outDoc,
        " Simulator terminated at time %f\n after sending %d msgs from layer5\n",
        time, nsim);
}

void init() /* initialize the simulator */
{
    int i;
    float sum, avg;
    float jimsrand();

    printf("-----  Stop and Wait Network Simulator Version 1.1 -------- \n\n");
    printf("Enter the number of messages to simulate: ");
    scanf("%d",&nsimmax);
    printf("Enter  packet loss probability [enter 0.0 for no loss]:");
    scanf("%f",&lossprob);
    printf("Enter packet corruption probability [0.0 for no corruption]:");
    scanf("%f",&corruptprob);
    printf("Enter average time between messages from sender's layer5 [ > 0.0]:");
    scanf("%f",&lambda);
    printf("Enter TRACE:");
    scanf("%d",&TRACE);

    srand(9999); /* init random number generator */
    sum = 0.0;   /* test random number generator for students */
    for (i = 0; i < 1000; i++)
        sum = sum + jimsrand(); /* jimsrand() should be uniform in [0,1] */
    avg = sum / 1000.0;
    if (avg < 0.25 || avg > 0.75)
    {
        printf("It is likely that random number generation on your machine\n");
        printf("is different from what this emulator expects.  Please take\n");
        printf("a look at the routine jimsrand() in the emulator code. Sorry. \n");
        exit(1);
    }

    ntolayer3 = 0;
    nlost = 0;
    ncorrupt = 0;

    time = 0.0;              /* initialize time to 0.0 */
    generate_next_arrival(); /* initialize event list */
}

/****************************************************************************/
/* jimsrand(): return a float in range [0,1].  The routine below is used to */
/* isolate all random number generation in one location.  We assume that the*/
/* system-supplied rand() function return an int in therange [0,mmm]        */
/****************************************************************************/
float jimsrand(void)
{
    double mmm = RAND_MAX;
    float x;                 /* individual students may need to change mmm */
    x = rand() / mmm;        /* x should be uniform in [0,1] */
    return (x);
}

/********************* EVENT HANDLINE ROUTINES *******/
/*  The next set of routines handle the event list   */
/*****************************************************/

void generate_next_arrival(void)
{
    double x, log(), ceil();
    struct event *evptr;
    float ttime;
    int tempint;

    if (TRACE > 2)
        fprintf(outDoc,"          GENERATE NEXT ARRIVAL: creating new arrival\n");

    x = lambda * jimsrand() * 2; /* x is uniform on [0,2*lambda] */
    /* having mean of lambda        */
    evptr = (struct event *)malloc(sizeof(struct event));
    evptr->evtime = time + x;
    evptr->evtype = FROM_LAYER5;
    if (BIDIRECTIONAL && (jimsrand() > 0.5))
        evptr->eventity = B;
    else
        evptr->eventity = A;
    insertevent(evptr);
}

void insertevent(struct event *p)
{
    struct event *q, *qold;

    if (TRACE > 2)
    {
        fprintf(outDoc,"            INSERTEVENT: time is %lf\n", time);
        fprintf(outDoc,"            INSERTEVENT: future time will be %lf\n", p->evtime);
    }
    q = evlist;      /* q points to header of list in which p struct inserted */
    if (q == NULL)   /* list is empty */
    {
        evlist = p;
        p->next = NULL;
        p->prev = NULL;
    }
    else
    {
        for (qold = q; q != NULL && p->evtime > q->evtime; q = q->next)
            qold = q;
        if (q == NULL)   /* end of list */
        {
            qold->next = p;
            p->prev = qold;
            p->next = NULL;
        }
        else if (q == evlist)     /* front of list */
        {
            p->next = evlist;
            p->prev = NULL;
            p->next->prev = p;
            evlist = p;
        }
        else     /* middle of list */
        {
            p->next = q;
            p->prev = q->prev;
            q->prev->next = p;
            q->prev = p;
        }
    }
}

void printevlist(void)
{
    struct event *q;
    int i;
    fprintf(outDoc,"--------------\nEvent List Follows:\n");
    for (q = evlist; q != NULL; q = q->next)
    {
        fprintf(outDoc,"Event time: %f, type: %d entity: %d\n", q->evtime, q->evtype,
               q->eventity);
    }
    fprintf(outDoc,"--------------\n");
}

/********************** Student-callable ROUTINES ***********************/

/* called by students routine to cancel a previously-started timer */
void stoptimer(int AorB /* A or B is trying to stop timer */)
{
    struct event *q, *qold;

    if (TRACE > 2)
        fprintf(outDoc,"          STOP TIMER: stopping timer at %f\n", time);
    /* for (q=evlist; q!=NULL && q->next!=NULL; q = q->next)  */
    for (q = evlist; q != NULL; q = q->next)
        if ((q->evtype == TIMER_INTERRUPT && q->eventity == AorB))
        {
            /* remove this event */
            if (q->next == NULL && q->prev == NULL)
                evlist = NULL;          /* remove first and only event on list */
            else if (q->next == NULL) /* end of list - there is one in front */
                q->prev->next = NULL;
            else if (q == evlist)   /* front of list - there must be event after */
            {
                q->next->prev = NULL;
                evlist = q->next;
            }
            else     /* middle of list */
            {
                q->next->prev = q->prev;
                q->prev->next = q->next;
            }
            free(q);
            return;
        }
    fprintf(outDoc,"Warning: unable to cancel your timer. It wasn't running.\n");
}

void starttimer(int AorB /* A or B is trying to start timer */, float increment)
{
    struct event *q;
    struct event *evptr;

    if (TRACE > 2)
        fprintf(outDoc,"          START TIMER: starting timer at %f\n", time);
    /* be nice: check to see if timer is already started, if so, then  warn */
    /* for (q=evlist; q!=NULL && q->next!=NULL; q = q->next)  */
    for (q = evlist; q != NULL; q = q->next)
        if ((q->evtype == TIMER_INTERRUPT && q->eventity == AorB))
        {
            fprintf(outDoc,"Warning: attempt to start a timer that is already started\n");
            return;
        }

    /* create future event for when timer goes off */
    evptr = (struct event *)malloc(sizeof(struct event));
    evptr->evtime = time + increment;
    evptr->evtype = TIMER_INTERRUPT;
    evptr->eventity = AorB;
    insertevent(evptr);
}

/************************** TOLAYER3 ***************/
void tolayer3(int AorB, struct pkt packet)
{
    struct pkt *mypktptr;
    struct event *evptr, *q;
    float lastime, x;
    int i;

    ntolayer3++;

    /* simulate losses: */
    if (jimsrand() < lossprob)
    {
        nlost++;
        if (TRACE > 0)
            fprintf(outDoc,"          TOLAYER3: packet being lost\n");
        return;
    }

    /* make a copy of the packet student just gave me since he/she may decide */
    /* to do something with the packet after we return back to him/her */
    mypktptr = (struct pkt *)malloc(sizeof(struct pkt));
    mypktptr->seqnum = packet.seqnum;
    mypktptr->acknum = packet.acknum;
    mypktptr->checksum = packet.checksum;
    for (i = 0; i < 20; i++)
        mypktptr->payload[i] = packet.payload[i];
    if (TRACE > 2)
    {
        fprintf(outDoc,"          TOLAYER3: seq: %d, ack %d, check: %d ", mypktptr->seqnum,
               mypktptr->acknum, mypktptr->checksum);
        for (i = 0; i < 20; i++)
            fprintf(outDoc,"%c", mypktptr->payload[i]);
        fprintf(outDoc,"\n");
    }

    /* create future event for arrival of packet at the other side */
    evptr = (struct event *)malloc(sizeof(struct event));
    evptr->evtype = FROM_LAYER3;      /* packet will pop out from layer3 */
    evptr->eventity = (AorB + 1) % 2; /* event occurs at other entity */
    evptr->pktptr = mypktptr;         /* save ptr to my copy of packet */
    /* finally, compute the arrival time of packet at the other end.
       medium can not reorder, so make sure packet arrives between 1 and 10
       time units after the latest arrival time of packets
       currently in the medium on their way to the destination */
    lastime = time;
    /* for (q=evlist; q!=NULL && q->next!=NULL; q = q->next) */
    for (q = evlist; q != NULL; q = q->next)
        if ((q->evtype == FROM_LAYER3 && q->eventity == evptr->eventity))
            lastime = q->evtime;
    evptr->evtime = lastime + 1 + 9 * jimsrand();

    /* simulate corruption: */
    if (jimsrand() < corruptprob)
    {
        ncorrupt++;
        if ((x = jimsrand()) < .75)
            mypktptr->payload[0] = 'Z'; /* corrupt payload */
        else if (x < .875)
            mypktptr->seqnum = 999999;
        else
            mypktptr->acknum = 999999;
        if (TRACE > 0)
            fprintf(outDoc,"          TOLAYER3: packet being corrupted\n");
    }

    if (TRACE > 2)
        fprintf(outDoc,"          TOLAYER3: scheduling arrival on other side\n");
    insertevent(evptr);
}

void tolayer5(int AorB, char datasent[20])
{
    int i;
    if (TRACE > 2)
    {
        fprintf(outDoc,"          TOLAYER5: data received: ");
        for (i = 0; i < 20; i++)
            fprintf(outDoc,"%c", datasent[i]);
        fprintf(outDoc,"\n");
    }
}
